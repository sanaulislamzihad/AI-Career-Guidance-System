import socket

HOST = "127.0.0.1"
PORT = 22000
BUFFER_SIZE = 1024

server = socket.socket()
server.bind((HOST, PORT))
server.listen()
print(f"Server is listening on {HOST}:{PORT}")

while True:
    client, address = server.accept()
    print(f"Client connected from {address[0]}:{address[1]}")

    client.send(b"Welcome! Please introduce yourself.")

    username = client.recv(BUFFER_SIZE).decode().strip()
    print("Client reply -> ", username)

    reply = "Nice to meet you, " + username + "!"
    client.send(reply.encode())

    client.close()
    print("Connection closed. Waiting for next client...\n")
