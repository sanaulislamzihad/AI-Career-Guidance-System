import socket

HOST = "127.0.0.1"
PORT = 22000
BUFFER_SIZE = 1024

client = socket.socket()
client.connect((HOST, PORT))
print(f"Client connected to {HOST}:{PORT}")

response = client.recv(BUFFER_SIZE).decode().strip()
print("Server reply -> ", response)

user_input = input("Enter your username: ").strip()
client.sendall(user_input.encode())

response = client.recv(BUFFER_SIZE).decode().strip()
print("Server reply -> ", response)

client.close()
